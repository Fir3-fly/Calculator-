let numbers = document.querySelectorAll(".number");
let display = document.getElementById("display");

let firstNumber = "";
let secondNumber = "";
let operator = "";
let calculationDone = false;


// Numbers

numbers.forEach(function(button) {
   button.addEventListener("click", function() {
      
      if (calculationDone || display.textContent === "Error") {
         display.textContent = button.textContent;
         firstNumber = button.textContent;
         secondNumber = "";
         operator = "";
         calculationDone = false;
         
      } else if (operator !== "") {
         
         secondNumber = secondNumber + button.textContent;
         
         display.textContent = firstNumber + " " + operator + " " + secondNumber;
         
      } else {
         
         if (display.textContent === "0") {
            display.textContent = button.textContent;
            firstNumber = button.textContent;
         } else {
            firstNumber = firstNumber + button.textContent;
            display.textContent = firstNumber;
         }
         
      }
      
   });
});


// Operators

let operators = document.querySelectorAll(".operator");

operators.forEach(function(button) {
   button.addEventListener("click", function() {
      
      if (display.textContent === "Error") {
         return;
      }
      
      if (firstNumber !== "") {
         operator = button.textContent;
         
         display.textContent = firstNumber + " " + operator;
         
         secondNumber = "";
      }
      
   });
});


// Equals

let equal = document.querySelector(".equal");

equal.addEventListener("click", function() {
   
   if (firstNumber === "" || secondNumber === "" || operator === "") {
      return;
   }
   
   let result;
   
   if (operator === "+") {
      result = Number(firstNumber) + Number(secondNumber);
      
   } else if (operator === "-") {
      result = Number(firstNumber) - Number(secondNumber);
      
   } else if (operator === "*") {
      result = Number(firstNumber) * Number(secondNumber);
      
   } else if (operator === "/") {
      
      if (Number(secondNumber) === 0) {
         display.textContent = "Error";
         calculationDone = true;
         return;
      }
      
      result = Number(firstNumber) / Number(secondNumber);
   }
   
   display.textContent = result;
   
   firstNumber = result;
   secondNumber = "";
   operator = "";
   
   calculationDone = true;
   
});


// AC

let ac = document.querySelector(".ac");

ac.addEventListener("click", function() {
   
   display.textContent = "0";
   
   firstNumber = "";
   secondNumber = "";
   operator = "";
   
   calculationDone = false;
   
});


// DEL

let del = document.querySelector(".del");

del.addEventListener("click", function() {
   
   if (display.textContent === "Error") {
      return;
   }
   
   if (operator !== "" && secondNumber !== "") {
      
      secondNumber = secondNumber.slice(0, -1);
      
      if (secondNumber === "") {
         display.textContent = firstNumber + " " + operator;
      } else {
         display.textContent = firstNumber + " " + operator + " " + secondNumber;
      }
      
   } else if (operator !== "") {
      
      operator = "";
      display.textContent = firstNumber;
      
   } else {
      
      firstNumber = firstNumber.slice(0, -1);
      
      if (firstNumber === "") {
         display.textContent = "0";
      } else {
         display.textContent = firstNumber;
      }
      
   }
   
});


// Decimal

let decimal = document.querySelector(".decimal");

decimal.addEventListener("click", function() {
   
   if (display.textContent === "Error") {
      return;
   }
   
   if (operator !== "") {
      
      if (secondNumber === "") {
         secondNumber = "0.";
      } else if (!secondNumber.includes(".")) {
         secondNumber = secondNumber + ".";
      }
      
      display.textContent = firstNumber + " " + operator + " " + secondNumber;
      
   } else {
      
      if (!firstNumber.includes(".")) {
         
         if (firstNumber === "") {
            firstNumber = "0.";
         } else {
            firstNumber = firstNumber + ".";
         }
         
         display.textContent = firstNumber;
      }
      
   }
   
});


// +/-

let sign = document.querySelector(".sign");

sign.addEventListener("click", function() {
   
   if (display.textContent === "Error") {
      return;
   }
   
   if (operator !== "" && secondNumber !== "") {
      
      secondNumber = Number(secondNumber) * -1;
      
      display.textContent = firstNumber + " " + operator + " " + secondNumber;
      
   } else if (operator === "" && firstNumber !== "") {
      
      firstNumber = Number(firstNumber) * -1;
      
      display.textContent = firstNumber;
      
   }
   
});


// Percentage

let percent = document.querySelector(".percent");

percent.addEventListener("click", function() {
   
   if (display.textContent === "Error") {
      return;
   }
   
   if (operator !== "" && secondNumber !== "") {
      
      secondNumber = Number(secondNumber) / 100;
      
      display.textContent = firstNumber + " " + operator + " " + secondNumber;
      
   } else if (operator === "" && firstNumber !== "") {
      
      firstNumber = Number(firstNumber) / 100;
      
      display.textContent = firstNumber;
      
   }
   
});